package com.badan.pack;
import javax.persistence.*;

public class StudentMain {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("badan");
		EntityManager em=emf.createEntityManager();
		EntityTransaction t=em.getTransaction();
		t.begin();
		
		StudentPojo sp=new StudentPojo();
		sp.setSno(2);
		sp.setSname("Badan Singh");
		sp.setSemail("sbadan49@yahoo.com");
		
		em.persist(sp);
		
		t.commit();
		em.close();
		emf.close();
		System.out.println("insert the data sucessfully ");
	}

}
