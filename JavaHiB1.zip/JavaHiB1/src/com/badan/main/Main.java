package com.badan.main;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.badan.pojo.Employee;

public class Main {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session s = sf.openSession();
		Employee employee=s.get(Employee.class, 2);
		if(employee==null)
		{
			System.out.println("Record not found");
		}
		else {
			System.out.println("id=> "+employee.getSid());
			System.out.println("name=> "+employee.getSname());
			System.out.println("lastname=>"+employee.getSlastname());
		}
		
//		 Transaction t=s.beginTransaction();
//		 t.commit();
//		 
		System.out.println("fake object not found...");

		s.close();
		sf.close();
	}

}
