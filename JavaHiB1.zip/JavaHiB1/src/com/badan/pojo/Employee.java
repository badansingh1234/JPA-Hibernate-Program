package com.badan.pojo;

public class Employee {
	
	private int sid;
	private String sname;
	private String slastname;
	
	public Employee() {

	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSlastname() {
		return slastname;
	}

	public void setSlastname(String slastname) {
		this.slastname = slastname;
	}

	@Override
	public String toString() {
		return "Employee [sid=" + sid + ", sname=" + sname + ", slastname=" + slastname + "]";
	}
	
	
}
