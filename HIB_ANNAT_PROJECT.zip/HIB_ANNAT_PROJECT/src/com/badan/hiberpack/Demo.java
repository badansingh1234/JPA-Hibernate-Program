package com.badan.hiberpack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Demo {

	public static void main(String[] args) {
		
		Configuration cfg =new Configuration();
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(Student.class);
		
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session s=sf.openSession();
		
		Student student=new Student();
		//student.setSid(101);
		student.setSname("Badan Singh");
		student.setSphone("8307152871");
		student.setScity("Mathura");
		
		s.persist(student);
		
		Transaction t=s.beginTransaction();
		t.commit();
		
		System.out.println("Add Object Sucessfully");
		s.close();
		sf.close();
	}

}
