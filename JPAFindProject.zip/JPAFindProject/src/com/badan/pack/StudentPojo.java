package com.badan.pack;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studentpojo")
public class StudentPojo {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno;
	private String sname;
	private String semail;
	
	public StudentPojo() {}

	public StudentPojo(Integer sno, String sname, String semail) {
		this.sno = sno;	this.sname = sname;this.semail = semail;
	}

	public Integer getSno() {
		return sno;
	}

	public void setSno(Integer sno) {
		this.sno = sno;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSemail() {
		return semail;
	}

	public void setSemail(String semail) {
		this.semail = semail;
	}

	@Override
	public String toString() {
		return "StudentPojo [sno=" + sno + ", sname=" + sname + ", semail=" + semail + "]";
	}
	
	
	
	
}
