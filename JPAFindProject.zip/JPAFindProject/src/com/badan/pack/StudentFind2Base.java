package com.badan.pack;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentFind2Base {

	public static void main(String[] args) {
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("badan");
		EntityManager em=emf.createEntityManager();
		
		String jpql="select sp.semail, sp.sname StudentPojo sp";
		Query q=em.createQuery(jpql);
		
		@SuppressWarnings("unchecked")
		List<Object[]> list=q.getResultList();
		Iterator<Object[]> itr=list.iterator();
		
		System.out.println("Name And Email Find Out all Objects ...");
		while(itr.hasNext())
		{
			Object[] ob=itr.next();
			System.out.println(ob[0]+" "+ob[1]);
		}
		em.close();
		emf.close();
		
	}
   
}
