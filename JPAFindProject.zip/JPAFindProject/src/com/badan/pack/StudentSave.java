package com.badan.pack;
import javax.persistence.*;

public class StudentSave {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("badan");
		EntityManager em=emf.createEntityManager();
		EntityTransaction t=em.getTransaction();
		t.begin();
		
		StudentPojo sp=new StudentPojo();
		sp.setSno(1);
		sp.setSname("Badan Singh");
		sp.setSemail("sbadan49@yahoo.com");
		
		StudentPojo sp1=new StudentPojo();
		sp1.setSno(2);
		sp1.setSname("Tushar Yadav");
		sp1.setSemail("tushar232@gmail.com");
			
		StudentPojo sp3 =new StudentPojo();
		sp3.setSno(3);
		sp3.setSname("Manish kumar");
		sp3.setSemail("manish21@gmail.com");
		
		em.persist(sp3);
		em.persist(sp);
		em.persist(sp1);
		
		t.commit();
		em.close();
		emf.close();
		System.out.println("Objects Save sucessfully... ");
	}

}
