package com.badan.pack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentRunUpdate {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("badan");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		String jpql="update StudentPojo sp set sp.semail:?1,sp.sname:?2 where sp.sno=2";
		Query q=em.createQuery(jpql);
		q.setParameter(1,"mnsh2223@gmail.com");
		q.setParameter(2, "Manish Kumar");
		q.setParameter(3, 3);
		
		et.commit();
		em.close();
		emf.close();
		System.out.println("Updated Object Sucessfully.. ");
	}

}
