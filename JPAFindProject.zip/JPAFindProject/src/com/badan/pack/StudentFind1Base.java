package com.badan.pack;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class StudentFind1Base {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("badan");
		EntityManager em=emf.createEntityManager();
		
		String jpql="select sp.sname from StudentPojo sp";
		Query q=em.createQuery(jpql);
		
		@SuppressWarnings("unchecked")
		List<String> list=q.getResultList();
		Iterator<String> itr=list.iterator();
		while(itr.hasNext())
		{
			String str=itr.next();
			System.out.println(str);
		}
		em.close();
		emf.close();
		System.out.println("Find Out Name Column All Objects .....");
	}

}
