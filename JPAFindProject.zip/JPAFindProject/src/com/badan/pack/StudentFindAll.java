package com.badan.pack;

import java.util.Iterator;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class StudentFindAll {

	public static void main(String[] args) {
		
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("badan");
		EntityManager entityManager =entityManagerFactory.createEntityManager();
		
		String jpql="Select sp from StudentPojo sp";
		Query query=entityManager.createQuery(jpql);
		
		@SuppressWarnings("unchecked")
		List<StudentPojo> list=query.getResultList();
		
		Iterator<StudentPojo> iterator=list.iterator();
		
		while(iterator.hasNext())
		{
			StudentPojo sp=iterator.next();
			System.out.println(sp.getSno()+" "+sp.getSname()+" "+sp.getSemail());
		}
		entityManager.close();
		entityManagerFactory.close();
		System.out.println("Find Out All Objects ...");
	}

}
