package com.badan.pack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentUpdate {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("badan");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		String jpql="update StudentPojo sp set sp.sname='Anku Pandey',sp.semail='anku234@gmail.com' where sp.sno=3";
		Query q=em.createQuery(jpql);
		q.executeUpdate();
		et.commit();
		em.close();
		emf.close();
		System.out.println("SNO=>3  OBJECT IS UPDATED..");
	}

}
