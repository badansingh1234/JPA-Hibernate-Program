package com.badan.pack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentDelete {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("badan");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		String jpql="delete from StudentPojo sp where sp.sno=3";
		Query q=em.createQuery(jpql);
		q.executeUpdate(); //ye dmltype(sql query ke liye methhod)  
		et.commit();
		em.close();
		emf.close();
		System.out.println("SNO => 3 Object Delete ....");
	}

}
