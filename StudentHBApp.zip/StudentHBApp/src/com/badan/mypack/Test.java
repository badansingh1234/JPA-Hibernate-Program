package com.badan.mypack;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;


import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.badan.pojo.Employee;

public class Test {

	public static void main(String[] args) {

				System.out.println("Running this class only");
				
				Configuration cfg=new Configuration(); //load the configration file
				cfg.configure("hibernate.cfg.xml");
				
				SessionFactory sf=cfg.buildSessionFactory(); //
				
				Session s=sf.openSession();
				
				Employee employee=s.get(Employee.class,1);
				if(employee==null)
				{
					System.out.println("Record not Found");
				}
				else {
				System.out.println("empid= "+employee.getEmpid());
				System.out.println("empname= "+employee.getEmpname());
				System.out.println("empsal= "+employee.getEmpsal());
				
				System.out.println(employee);
				}
				
//				try {
////				//Employee employee=s.load(Employee.class,4);
//					//Employee employee=(Employee) s.load("com.badan.pojo.Employee",2);
//				System.out.println("empid=>"+employee.getEmpid());
//				System.out.println("empname=>"+employee.getEmpname());
//				System.out.println("empsal=>"+employee.getEmpsal());
//				System.out.println(employee);
//				}
//				catch(ObjectNotFoundException oe)
//				{
//					System.out.println(oe);
//				}
//				
				
				
				
//				Employee employee=s.get(Employee.class,3);
//				System.out.println("empid=> "+employee.getEmpid());
//				System.out.println("empname=> "+employee.getEmpname());
//				System.out.println("empsal=> "+employee.getEmpsal());
//				
//				System.out.println(employee);
//				
//				catch(ObjectNotFoundException oe)
//				{
//					System.out.println(oe);
//				}
//				Employee employee=new Employee();
//				employee.setEmpid(3);
				//employee.setEmpname("kabootar kaliya");
				//employee.setEmpsal(99464.6);
				
				//s.save(employee); //s.save(employee)
				
				//s.saveOrUpdate(employee);
				
//				Transaction t=s.beginTransaction();
//				t.commit();
				
				System.out.println("get record on console  sucessfully");
				
				s.close();
				sf.close();
				
				
			}
		
}



