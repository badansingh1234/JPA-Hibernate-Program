package com.badan.core.program;

public interface Test {
		void display();
}
