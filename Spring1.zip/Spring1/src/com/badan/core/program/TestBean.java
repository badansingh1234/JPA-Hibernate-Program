package com.badan.core.program;

public class TestBean implements Test {

	@Override
	public void display() {
		System.out.println("Hello User...");
	}

}
